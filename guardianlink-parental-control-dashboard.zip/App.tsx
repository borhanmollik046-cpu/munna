
import React, { useState, useEffect } from 'react';
import { 
  LayoutDashboard, MapPin, PhoneCall, Monitor, ShieldCheck, 
  Settings, LogOut, Bell, Cpu, Smartphone, UserCheck, Plus, X, QrCode
} from 'lucide-react';
import DashboardView from './components/DashboardView';
import MapView from './components/MapView';
import CallLogView from './components/CallLogView';
import ScreenCaptureView from './components/ScreenCaptureView';
import AIInsightView from './components/AIInsightView';
import ChildClientView from './components/ChildClientView';
import { socketService } from './services/socketService';

const App: React.FC = () => {
  const [role, setRole] = useState<'parent' | 'child' | null>(null);
  const [activeTab, setActiveTab] = useState<'dashboard' | 'map' | 'calls' | 'screens' | 'ai'>('dashboard');
  const [showPairingModal, setShowPairingModal] = useState(false);
  const [pairingCode, setPairingCode] = useState<string | null>(null);

  // Auto-detect role if URL contains 'pair' (useful for QR code scanning)
  useEffect(() => {
    if (window.location.pathname.includes('/pair/')) {
      setRole('child');
    }
  }, []);

  const handleStartPairing = () => {
    socketService.connect();
    socketService.requestPairingCode((code) => {
      setPairingCode(code);
      setShowPairingModal(true);
    });
  };

  if (!role) {
    return (
      <div className="min-h-screen bg-slate-950 flex items-center justify-center p-6 select-none">
        <div className="max-w-md w-full space-y-12 text-center">
          <div className="relative inline-block">
            <div className="absolute inset-0 bg-indigo-500 blur-3xl opacity-20 animate-pulse"></div>
            <div className="relative bg-indigo-600 w-24 h-24 rounded-[2rem] shadow-2xl flex items-center justify-center mx-auto rotate-3 hover:rotate-0 transition-transform duration-500">
              <ShieldCheck className="text-white w-12 h-12" />
            </div>
          </div>
          
          <div>
            <h1 className="text-5xl font-black text-white tracking-tighter italic">
              GUARDIAN<span className="text-indigo-500">LINK</span>
            </h1>
            <p className="text-slate-500 mt-4 font-medium max-w-xs mx-auto">Advanced digital oversight for the next generation.</p>
          </div>
          
          <div className="grid gap-5 pt-4">
            <RoleButton 
              onClick={() => setRole('parent')}
              variant="indigo"
              icon={<UserCheck className="w-8 h-8" />}
              title="Parental Hub"
              desc="Monitor your family's safety"
            />

            <RoleButton 
              onClick={() => setRole('child')}
              variant="emerald"
              icon={<Smartphone className="w-8 h-8" />}
              title="Child Device"
              desc="Connect and secure this phone"
            />
          </div>
          
          <p className="text-[10px] text-slate-700 font-bold uppercase tracking-widest">Version 2.4.0 Production Ready</p>
        </div>
      </div>
    );
  }

  if (role === 'child') {
    return <ChildClientView onExit={() => setRole(null)} />;
  }

  return (
    <div className="flex h-screen bg-slate-50 overflow-hidden font-sans">
      {/* Sidebar */}
      <aside className="w-80 bg-white border-r border-slate-200 flex flex-col hidden xl:flex">
        <div className="p-10 border-b border-slate-100 flex items-center gap-4">
          <div className="bg-indigo-600 p-2.5 rounded-2xl shadow-xl shadow-indigo-100">
            <ShieldCheck className="text-white w-7 h-7" />
          </div>
          <h1 className="font-black text-3xl text-slate-800 tracking-tighter italic">G-LINK</h1>
        </div>

        <div className="p-8">
          <button 
            onClick={handleStartPairing}
            className="w-full bg-slate-900 text-white p-5 rounded-3xl font-black text-sm uppercase tracking-widest flex items-center justify-center gap-3 hover:bg-indigo-600 transition-all shadow-2xl shadow-slate-200 active:scale-[0.98]"
          >
            <Plus className="w-5 h-5" />
            Connect Device
          </button>
        </div>

        <nav className="flex-1 px-6 space-y-2">
          <SidebarItem icon={<LayoutDashboard className="w-5 h-5" />} label="Overview" active={activeTab === 'dashboard'} onClick={() => setActiveTab('dashboard')} />
          <SidebarItem icon={<MapPin className="w-5 h-5" />} label="Live GPS" active={activeTab === 'map'} onClick={() => setActiveTab('map')} />
          <SidebarItem icon={<PhoneCall className="w-5 h-5" />} label="Call Logs" active={activeTab === 'calls'} onClick={() => setActiveTab('calls')} />
          <SidebarItem icon={<Monitor className="w-5 h-5" />} label="Screenshots" active={activeTab === 'screens'} onClick={() => setActiveTab('screens')} />
          <SidebarItem icon={<Cpu className="w-5 h-5" />} label="AI Safety Agent" active={activeTab === 'ai'} onClick={() => setActiveTab('ai')} />
        </nav>

        <div className="p-8 border-t border-slate-100 space-y-2">
          <SidebarItem icon={<Settings className="w-5 h-5" />} label="Settings" />
          <SidebarItem icon={<LogOut className="w-5 h-5" />} label="Exit Dashboard" onClick={() => setRole(null)} />
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="h-24 bg-white border-b border-slate-200 flex items-center justify-between px-10 shrink-0">
          <div className="flex items-center gap-4">
             <div className="lg:hidden bg-indigo-600 p-2 rounded-lg">
                <ShieldCheck className="text-white w-5 h-5" />
             </div>
             <h2 className="text-2xl font-black text-slate-800 uppercase tracking-tighter">
              {activeTab}
            </h2>
          </div>
          <div className="flex items-center gap-8">
            <button className="relative p-3 text-slate-400 hover:text-indigo-600 transition-colors bg-slate-50 rounded-2xl">
              <Bell className="w-6 h-6" />
              <span className="absolute top-3.5 right-3.5 w-3 h-3 bg-rose-500 rounded-full border-2 border-white"></span>
            </button>
            <div className="flex items-center gap-4 pl-4 border-l border-slate-100">
               <div className="text-right hidden sm:block">
                  <p className="text-sm font-black text-slate-800">Admin Parent</p>
                  <p className="text-[10px] text-slate-400 font-bold uppercase tracking-widest">Verified Account</p>
               </div>
               <div className="h-12 w-12 rounded-2xl bg-indigo-50 border-2 border-indigo-100 flex items-center justify-center overflow-hidden shadow-inner">
                <img src="https://picsum.photos/seed/admin/100" alt="Avatar" className="w-full h-full object-cover" />
              </div>
            </div>
          </div>
        </header>

        <div className="flex-1 overflow-y-auto p-10 bg-slate-50/50">
          {activeTab === 'dashboard' && <DashboardView />}
          {activeTab === 'map' && <MapView />}
          {activeTab === 'calls' && <CallLogView />}
          {activeTab === 'screens' && <ScreenCaptureView />}
          {activeTab === 'ai' && <AIInsightView />}
        </div>
      </main>

      {/* Pairing Modal */}
      {showPairingModal && (
        <div className="fixed inset-0 z-[100] bg-slate-900/90 backdrop-blur-md flex items-center justify-center p-6">
          <div className="bg-white w-full max-w-md rounded-[3rem] shadow-2xl overflow-hidden animate-in zoom-in-95 duration-500 border border-white/20">
            <div className="p-10 border-b border-slate-100 flex items-center justify-between bg-slate-50/50">
              <h3 className="text-2xl font-black text-slate-800 tracking-tighter italic">PAIR DEVICE</h3>
              <button onClick={() => setShowPairingModal(false)} className="p-3 hover:bg-white rounded-2xl transition-all shadow-sm">
                <X className="w-6 h-6 text-slate-400" />
              </button>
            </div>
            
            <div className="p-12 text-center space-y-10">
              <div className="space-y-6">
                <p className="text-[11px] font-black text-indigo-500 uppercase tracking-[0.3em]">Scan to Link</p>
                <div className="bg-white p-8 rounded-[3rem] inline-block shadow-[0_20px_50px_rgba(0,0,0,0.05)] border-2 border-slate-50">
                  <img 
                    src={`https://api.qrserver.com/v1/create-qr-code/?size=250x250&data=${window.location.origin}/pair/${pairingCode}`} 
                    alt="QR Code" 
                    className="w-48 h-48 mix-blend-multiply"
                  />
                </div>
              </div>

              <div className="relative">
                <div className="absolute inset-0 flex items-center"><div className="w-full border-t border-slate-100"></div></div>
                <div className="relative flex justify-center"><span className="bg-white px-6 text-xs font-black text-slate-300 uppercase tracking-[0.2em]">Manual Entry</span></div>
              </div>

              <div className="space-y-6">
                <div className="flex justify-center gap-4">
                  {pairingCode?.split('').map((digit, i) => (
                    <div key={i} className="w-16 h-20 bg-indigo-50 border-2 border-indigo-100 rounded-[1.5rem] flex items-center justify-center text-4xl font-black text-indigo-600 shadow-xl shadow-indigo-50">
                      {digit}
                    </div>
                  ))}
                </div>
              </div>

              <p className="text-[11px] text-slate-400 font-bold uppercase tracking-widest leading-relaxed">
                Open <span className="text-indigo-600 underline">GuardianLink.netlify.app</span> on the child's phone to connect.
              </p>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

const RoleButton: React.FC<{ onClick: () => void, variant: 'indigo' | 'emerald', icon: React.ReactNode, title: string, desc: string }> = ({ onClick, variant, icon, title, desc }) => (
  <button 
    onClick={onClick}
    className={`group bg-slate-900 hover:bg-${variant}-600 p-8 rounded-[2.5rem] border border-slate-800 transition-all text-left flex items-center gap-6 shadow-2xl hover:shadow-${variant}-500/20 active:scale-[0.98]`}
  >
    <div className={`bg-${variant}-500/20 p-5 rounded-3xl text-${variant}-400 group-hover:bg-white/20 group-hover:text-white transition-all duration-500 group-hover:rotate-6`}>
      {icon}
    </div>
    <div>
      <p className="font-black text-white text-2xl tracking-tight">{title}</p>
      <p className="text-sm text-slate-500 group-hover:text-white/80 transition-colors font-medium mt-1">{desc}</p>
    </div>
  </button>
);

const SidebarItem: React.FC<{ icon: React.ReactNode; label: string; active?: boolean; onClick?: () => void }> = ({ icon, label, active, onClick }) => (
  <button 
    onClick={onClick}
    className={`w-full flex items-center gap-4 px-8 py-5 rounded-[1.5rem] transition-all ${
      active 
        ? 'bg-indigo-600 text-white shadow-2xl shadow-indigo-100 font-bold scale-[1.02]' 
        : 'text-slate-400 hover:bg-slate-50 hover:text-slate-700'
    }`}
  >
    {icon}
    <span className="tracking-tight text-sm font-bold">{label}</span>
  </button>
);

export default App;
