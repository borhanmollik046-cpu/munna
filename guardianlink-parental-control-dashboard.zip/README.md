
# 🛡️ GuardianLink - Advanced Parental Dashboard

GuardianLink is a high-performance, real-time parental monitoring solution. It allows parents to track device locations, view live snapshots, and analyze safety risks using Google Gemini AI.

## ✨ Features

- **📍 Real-time GPS Tracking**: Monitor child device locations on an interactive map.
- **📸 Remote Snapshots**: Request live camera captures from the child's device.
- **📞 AI Call Analysis**: Automatically detect suspicious callers and risk patterns.
- **🤖 Gemini AI Agent**: Get daily safety summaries and actionable insights.
- **🔑 Secure Pairing**: Link devices instantly via 4-digit PIN or QR Code.
- **📱 PWA Ready**: Optimized for mobile browser "Add to Home Screen" usage.

## 🚀 Quick Start

### 1. Clone the repository
```bash
git clone https://github.com/your-username/guardian-link.git
cd guardian-link
```

### 2. Setup Environment Variables
Create a `.env` file in the root:
```env
API_KEY=your_google_gemini_api_key
VITE_SOCKET_URL=https://your-backend-url.com
```

### 3. Install & Run Backend
```bash
npm install
npm start
```

### 4. Deploy Frontend
- Push to GitHub.
- Connect to **Netlify**.
- Set `Build command` to: `(none or your build tool)`
- Set `Publish directory` to: `.` (root)

## 🛠️ Tech Stack

- **Frontend**: React (ESM), Tailwind CSS, Lucide Icons.
- **Backend**: Node.js, Express, Socket.io.
- **AI**: Google Generative AI (Gemini 3 Flash).
- **Communication**: WebSockets for low-latency updates.

## 📄 License
MIT License - See [LICENSE](LICENSE) for details.
