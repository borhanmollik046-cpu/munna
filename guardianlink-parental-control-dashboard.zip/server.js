
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: "*" }
});

app.use(express.json());

// In-memory storage for pairing codes (Code -> {parentSocketId, timestamp})
const activePairs = new Map();

io.on('connection', (socket) => {
  console.log('User connected:', socket.id);

  // Parent requests a new pairing code
  socket.on('request-pairing-code', () => {
    const code = Math.floor(1000 + Math.random() * 9000).toString();
    activePairs.set(code, { parentId: socket.id, timestamp: Date.now() });
    socket.join(`pair_${code}`);
    socket.emit('pairing-code-generated', code);
    console.log(`Pairing code ${code} generated for parent ${socket.id}`);
  });

  // Child attempts to link with a code
  socket.on('link-with-code', (code) => {
    if (activePairs.has(code)) {
      const pair = activePairs.get(code);
      socket.join(`pair_${code}`);
      
      // Notify both parties
      io.to(`pair_${code}`).emit('pairing-success', { 
        code, 
        childId: socket.id,
        parentAvailable: true 
      });
      
      console.log(`Device ${socket.id} linked successfully with code ${code}`);
    } else {
      socket.emit('pairing-error', 'Invalid or expired code');
    }
  });

  // Relay commands within the specific pairing room
  socket.on('parent-command', (data) => {
    const { code, command } = data;
    socket.to(`pair_${code}`).emit('child-command', command);
  });

  // Relay updates from child to the parent in the same room
  socket.on('child-update', (data) => {
    const { code, type, payload } = data;
    // We append the socket id as deviceId for identification
    payload.deviceId = socket.id; 
    socket.to(`pair_${code}`).emit('device-update', { type, payload });
  });

  socket.on('disconnect', () => {
    console.log('User disconnected:', socket.id);
  });
});

// Use environment PORT or default to 3000
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`GuardianLink Secure Bridge running on port ${PORT}`);
});
