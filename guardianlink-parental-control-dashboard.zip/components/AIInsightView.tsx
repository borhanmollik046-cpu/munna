
import React, { useState, useEffect } from 'react';
import { Sparkles, BrainCircuit, ShieldAlert, CheckCircle, Info, RefreshCw } from 'lucide-react';
import { getGeneralSafetyReport, analyzeCallLogs } from '../services/geminiService';
import { AISafetyInsight } from '../types';
import { MOCK_CALL_LOGS } from '../constants';

const AIInsightView: React.FC = () => {
  const [report, setReport] = useState<string>('Generating latest digital safety report...');
  const [insights, setInsights] = useState<AISafetyInsight[]>([]);
  const [loading, setLoading] = useState(true);

  const fetchData = async () => {
    setLoading(true);
    const [reportText, aiInsights] = await Promise.all([
      getGeneralSafetyReport(),
      analyzeCallLogs(MOCK_CALL_LOGS)
    ]);
    setReport(reportText);
    setInsights(aiInsights);
    setLoading(false);
  };

  useEffect(() => {
    fetchData();
  }, []);

  return (
    <div className="max-w-4xl mx-auto space-y-8">
      <div className="bg-gradient-to-br from-indigo-600 to-violet-700 rounded-3xl p-8 text-white relative overflow-hidden shadow-xl">
        <div className="absolute top-0 right-0 p-8 opacity-10">
          <BrainCircuit className="w-48 h-48" />
        </div>
        <div className="relative z-10">
          <div className="flex items-center justify-between mb-8">
            <div className="flex items-center gap-3">
              <div className="bg-white/20 p-2 rounded-xl backdrop-blur-md">
                <Sparkles className="w-6 h-6 text-indigo-100" />
              </div>
              <h2 className="text-2xl font-bold">Guardian AI Analysis</h2>
            </div>
            <button 
              onClick={fetchData}
              disabled={loading}
              className="p-2 hover:bg-white/10 rounded-full transition-colors disabled:opacity-50"
            >
              <RefreshCw className={`w-5 h-5 ${loading ? 'animate-spin' : ''}`} />
            </button>
          </div>

          <div className="space-y-4">
            <div className="bg-white/10 backdrop-blur-md p-6 rounded-2xl border border-white/20">
              <h3 className="text-lg font-bold mb-3 flex items-center gap-2">
                Daily Summary
                <span className="text-xs bg-indigo-400/30 px-2 py-0.5 rounded-full font-normal">Updated 2m ago</span>
              </h3>
              <p className="text-indigo-50 leading-relaxed whitespace-pre-line">
                {report}
              </p>
            </div>
          </div>
        </div>
      </div>

      <div className="space-y-4">
        <h3 className="text-lg font-bold text-slate-800 px-2">Critical Safety Insights</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {loading ? (
            Array(4).fill(0).map((_, i) => (
              <div key={i} className="h-32 bg-slate-100 animate-pulse rounded-2xl"></div>
            ))
          ) : (
            insights.map((insight, idx) => (
              <InsightCard key={idx} insight={insight} />
            ))
          )}
        </div>
      </div>

      <div className="bg-white p-6 rounded-2xl border border-slate-200">
        <h3 className="font-bold text-slate-800 mb-4">How Guardian AI Works</h3>
        <p className="text-sm text-slate-600 leading-relaxed">
          Guardian AI uses the Gemini Pro model to continuously scan incoming device data. It identifies linguistic patterns in screen text, recognizes suspicious contact behaviors, and cross-references unknown numbers with global risk databases. All analysis is done with privacy as a priority, summarizing findings only for your review.
        </p>
      </div>
    </div>
  );
};

const InsightCard: React.FC<{ insight: AISafetyInsight }> = ({ insight }) => {
  const getStyles = () => {
    switch(insight.type) {
      case 'warning': return { icon: <ShieldAlert className="w-5 h-5 text-rose-500" />, bg: 'bg-rose-50', border: 'border-rose-100' };
      case 'positive': return { icon: <CheckCircle className="w-5 h-5 text-emerald-500" />, bg: 'bg-emerald-50', border: 'border-emerald-100' };
      default: return { icon: <Info className="w-5 h-5 text-indigo-500" />, bg: 'bg-indigo-50', border: 'border-indigo-100' };
    }
  };

  const { icon, bg, border } = getStyles();

  return (
    <div className={`p-5 rounded-2xl border ${bg} ${border} transition-transform hover:scale-[1.01]`}>
      <div className="flex gap-4">
        <div className="shrink-0 pt-1">{icon}</div>
        <div className="space-y-2">
          <p className="text-sm font-bold text-slate-800 leading-tight">{insight.message}</p>
          <div className="bg-white/60 p-3 rounded-lg">
            <p className="text-[11px] font-bold text-slate-400 uppercase tracking-wider mb-1">Recommendation</p>
            <p className="text-xs text-slate-700 leading-relaxed">{insight.recommendation}</p>
          </div>
        </div>
      </div>
    </div>
  );
}

export default AIInsightView;
