
import React from 'react';
import { MOCK_CALL_LOGS } from '../constants';
import { PhoneIncoming, PhoneOutgoing, PhoneMissed, ShieldAlert, CheckCircle } from 'lucide-react';

const CallLogView: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="bg-white rounded-2xl shadow-sm border border-slate-200 overflow-hidden">
        <div className="p-6 border-b border-slate-100 flex items-center justify-between">
          <h3 className="font-bold text-slate-800 text-lg">Detailed Call History</h3>
          <div className="flex gap-2">
            <select className="bg-slate-50 border border-slate-200 rounded-lg px-3 py-1.5 text-sm text-slate-600 outline-none">
              <option>All Calls</option>
              <option>Incoming</option>
              <option>Outgoing</option>
              <option>Unknown</option>
            </select>
          </div>
        </div>
        <div className="overflow-x-auto">
          <table className="w-full text-left">
            <thead>
              <tr className="bg-slate-50 text-slate-400 text-xs font-semibold uppercase tracking-wider">
                <th className="px-6 py-4">Caller</th>
                <th className="px-6 py-4">Type</th>
                <th className="px-6 py-4">Duration</th>
                <th className="px-6 py-4">Time</th>
                <th className="px-6 py-4">AI Risk Check</th>
                <th className="px-6 py-4">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {MOCK_CALL_LOGS.map((log) => (
                <tr key={log.id} className="hover:bg-slate-50/50 transition-colors">
                  <td className="px-6 py-4">
                    <div className="flex items-center gap-3">
                      <div className="w-8 h-8 rounded-full bg-slate-100 flex items-center justify-center text-slate-400">
                        {log.contactName[0] || '?'}
                      </div>
                      <div>
                        <p className="text-sm font-semibold text-slate-700">{log.contactName}</p>
                        <p className="text-xs text-slate-400">{log.phoneNumber}</p>
                      </div>
                    </div>
                  </td>
                  <td className="px-6 py-4">
                    {log.type === 'incoming' && <span className="flex items-center gap-1 text-indigo-600 text-xs font-medium"><PhoneIncoming className="w-3 h-3" /> Incoming</span>}
                    {log.type === 'outgoing' && <span className="flex items-center gap-1 text-emerald-600 text-xs font-medium"><PhoneOutgoing className="w-3 h-3" /> Outgoing</span>}
                    {log.type === 'missed' && <span className="flex items-center gap-1 text-rose-600 text-xs font-medium"><PhoneMissed className="w-3 h-3" /> Missed</span>}
                  </td>
                  <td className="px-6 py-4 text-sm text-slate-500">{log.duration}</td>
                  <td className="px-6 py-4 text-sm text-slate-500">{log.timestamp}</td>
                  <td className="px-6 py-4">
                    {log.riskScore === 'low' ? (
                      <span className="inline-flex items-center gap-1 px-2 py-1 bg-emerald-50 text-emerald-700 rounded-full text-[10px] font-bold">
                        <CheckCircle className="w-3 h-3" /> SAFE
                      </span>
                    ) : (
                      <span className="inline-flex items-center gap-1 px-2 py-1 bg-rose-50 text-rose-700 rounded-full text-[10px] font-bold">
                        <ShieldAlert className="w-3 h-3" /> SUSPICIOUS
                      </span>
                    )}
                  </td>
                  <td className="px-6 py-4">
                    <button className="text-xs font-bold text-indigo-600 hover:text-indigo-800">Block Number</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};

export default CallLogView;
