
import React from 'react';
import { MOCK_SCREENSHOTS } from '../constants';
import { Eye, Calendar, Filter, Share2 } from 'lucide-react';

const ScreenCaptureView: React.FC = () => {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-medium text-slate-600 flex items-center gap-2 hover:bg-slate-50 transition">
            <Calendar className="w-4 h-4" />
            Today, July 24
          </button>
          <button className="px-4 py-2 bg-white border border-slate-200 rounded-lg text-sm font-medium text-slate-600 flex items-center gap-2 hover:bg-slate-50 transition">
            <Filter className="w-4 h-4" />
            Filter by App
          </button>
        </div>
        <p className="text-sm text-slate-400 italic">Captures occur every 15 minutes</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6">
        {MOCK_SCREENSHOTS.map((screen) => (
          <div key={screen.id} className="group bg-white rounded-2xl border border-slate-200 overflow-hidden hover:shadow-lg transition-all duration-300">
            <div className="relative aspect-video overflow-hidden">
              <img 
                src={screen.imageUrl} 
                alt={screen.appTitle} 
                className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/60 to-transparent opacity-0 group-hover:opacity-100 transition-opacity flex items-end p-4">
                <button className="bg-white/20 backdrop-blur text-white px-3 py-1.5 rounded-lg text-xs font-bold flex items-center gap-2">
                  <Eye className="w-3.5 h-3.5" /> Full Resolution
                </button>
              </div>
              <div className="absolute top-4 left-4">
                <span className="bg-indigo-600 text-white text-[10px] font-bold px-2 py-1 rounded shadow-lg uppercase tracking-wider">
                  {screen.appTitle}
                </span>
              </div>
              <div className="absolute top-4 right-4">
                <div className={`w-8 h-8 rounded-full border-2 flex items-center justify-center font-bold text-[10px] ${
                  screen.safetyRating > 80 ? 'border-emerald-500 bg-white text-emerald-500' : 'border-amber-500 bg-white text-amber-500'
                }`}>
                  {screen.safetyRating}%
                </div>
              </div>
            </div>
            
            <div className="p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="text-xs font-medium text-slate-400">{screen.timestamp}</span>
                <button className="text-slate-400 hover:text-slate-600">
                  <Share2 className="w-4 h-4" />
                </button>
              </div>
              <h4 className="text-sm font-bold text-slate-800 mb-2">AI Analysis:</h4>
              <p className="text-xs text-slate-600 leading-relaxed bg-slate-50 p-3 rounded-lg border border-slate-100">
                "{screen.aiDescription}"
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
};

export default ScreenCaptureView;
