
import React from 'react';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell } from 'recharts';
import { Smartphone, Battery, Signal, Zap, Clock, AlertTriangle } from 'lucide-react';
import { MOCK_USAGE } from '../constants';

const COLORS = ['#6366f1', '#f43f5e', '#10b981', '#f59e0b', '#8b5cf6'];

const DashboardView: React.FC = () => {
  return (
    <div className="space-y-6">
      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <StatCard 
          icon={<Smartphone className="text-indigo-600" />} 
          title="Active Device" 
          value="Pixel 7 Pro" 
          subtitle="Last synced: Just now" 
        />
        <StatCard 
          icon={<Battery className="text-emerald-600" />} 
          title="Battery" 
          value="82%" 
          subtitle="Charging: No" 
        />
        <StatCard 
          icon={<Clock className="text-amber-600" />} 
          title="Screen Time" 
          value="3h 45m" 
          subtitle="Daily Limit: 4h 00m" 
        />
        <StatCard 
          icon={<AlertTriangle className="text-rose-600" />} 
          title="Alerts" 
          value="2 New" 
          subtitle="High risk caller detected" 
        />
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        {/* Usage Chart */}
        <div className="lg:col-span-2 bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <div className="flex items-center justify-between mb-6">
            <h3 className="font-bold text-slate-800 text-lg">App Usage Analysis</h3>
            <span className="text-sm text-slate-400">Past 24 Hours</span>
          </div>
          <div className="h-80 w-full">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={MOCK_USAGE}>
                <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#f1f5f9" />
                <XAxis dataKey="appName" axisLine={false} tickLine={false} tick={{fill: '#94a3b8'}} />
                <YAxis axisLine={false} tickLine={false} tick={{fill: '#94a3b8'}} />
                <Tooltip 
                  cursor={{fill: '#f8fafc'}}
                  contentStyle={{ borderRadius: '12px', border: 'none', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}
                />
                <Bar dataKey="minutes" radius={[6, 6, 0, 0]}>
                  {MOCK_USAGE.map((entry, index) => (
                    <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                  ))}
                </Bar>
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Live Status */}
        <div className="bg-white p-6 rounded-2xl shadow-sm border border-slate-200">
          <h3 className="font-bold text-slate-800 text-lg mb-6 flex items-center gap-2">
            <Zap className="w-5 h-5 text-indigo-600 fill-indigo-600" />
            Live Feed
          </h3>
          <div className="space-y-4">
            <TimelineItem time="10:45 AM" label="Call Received" sub="Alex Smith" type="call" />
            <TimelineItem time="10:12 AM" label="Location Update" sub="Golden Gate Park" type="location" />
            <TimelineItem time="09:55 AM" label="App Opened" sub="TikTok (Educational)" type="app" />
            <TimelineItem time="09:30 AM" label="Alert" sub="Low Battery (15%)" type="alert" />
          </div>
        </div>
      </div>
    </div>
  );
};

const StatCard: React.FC<{ icon: React.ReactNode; title: string; value: string; subtitle: string }> = ({ 
  icon, title, value, subtitle 
}) => (
  <div className="bg-white p-5 rounded-2xl shadow-sm border border-slate-200 flex items-start gap-4">
    <div className="p-3 bg-slate-50 rounded-xl">{icon}</div>
    <div>
      <p className="text-sm font-medium text-slate-400 mb-1">{title}</p>
      <h4 className="text-2xl font-bold text-slate-800">{value}</h4>
      <p className="text-xs text-slate-500 mt-1">{subtitle}</p>
    </div>
  </div>
);

const TimelineItem: React.FC<{ time: string, label: string, sub: string, type: string }> = ({ time, label, sub, type }) => {
  const getIcon = () => {
    switch(type) {
      case 'call': return '📞';
      case 'location': return '📍';
      case 'app': return '📱';
      case 'alert': return '⚠️';
      default: return '•';
    }
  };
  return (
    <div className="flex gap-4">
      <span className="text-xs text-slate-400 w-16 pt-1 text-right">{time}</span>
      <div className="relative">
        <div className="w-8 h-8 rounded-full bg-slate-50 border border-slate-100 flex items-center justify-center text-xs z-10 relative">
          {getIcon()}
        </div>
        <div className="absolute top-8 bottom-0 left-1/2 -translate-x-1/2 w-0.5 bg-slate-100 -mb-4"></div>
      </div>
      <div>
        <p className="text-sm font-semibold text-slate-700">{label}</p>
        <p className="text-xs text-slate-500">{sub}</p>
      </div>
    </div>
  );
}

export default DashboardView;
