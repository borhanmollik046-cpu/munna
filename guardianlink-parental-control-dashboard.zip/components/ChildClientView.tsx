
import React, { useState, useEffect, useRef } from 'react';
import { Smartphone, ShieldCheck, MapPin, Camera, LogOut, CheckCircle, Wifi, Lock, ArrowRight, XCircle } from 'lucide-react';
import { socketService } from '../services/socketService';

const ChildClientView: React.FC<{ onExit: () => void }> = ({ onExit }) => {
  const [isLinked, setIsLinked] = useState(false);
  const [pin, setPin] = useState(['', '', '', '']);
  const [status, setStatus] = useState<'idle' | 'pairing' | 'online' | 'error'>('idle');
  const [errorMsg, setErrorMsg] = useState('');
  const [lastUpdate, setLastUpdate] = useState<string>('Never');
  
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);

  const handlePinChange = (val: string, index: number) => {
    if (val.length > 1) return;
    const newPin = [...pin];
    newPin[index] = val;
    setPin(newPin);
    
    // Auto-focus next
    if (val && index < 3) {
      const nextInput = document.getElementById(`pin-${index + 1}`);
      nextInput?.focus();
    }
  };

  const handlePair = () => {
    const code = pin.join('');
    if (code.length < 4) return;
    
    setStatus('pairing');
    setErrorMsg('');
    
    const socket = socketService.connect();
    socketService.linkWithCode(code, (success, err) => {
      if (success) {
        setIsLinked(true);
        setStatus('online');
        startTracking();
      } else {
        setStatus('error');
        setErrorMsg(err || 'Pairing failed');
      }
    });
  };

  const startTracking = () => {
    const socket = socketService.socket;
    if (!socket) return;

    // GPS Tracking
    if ("geolocation" in navigator) {
      navigator.geolocation.watchPosition(
        (position) => {
          socketService.sendUpdate('LOCATION', {
            lat: position.coords.latitude,
            lng: position.coords.longitude,
            accuracy: position.coords.accuracy,
            timestamp: Date.now()
          });
          setLastUpdate(new Date().toLocaleTimeString());
        },
        () => setStatus('error'),
        { enableHighAccuracy: true }
      );
    }

    // Camera Commands
    socket.on('child-command', async (command: any) => {
      if (command.type === 'REQUEST_SNAPSHOT') {
        try {
          const stream = await navigator.mediaDevices.getUserMedia({ video: { facingMode: 'user' } });
          if (videoRef.current) {
            videoRef.current.srcObject = stream;
            videoRef.current.play();
            setTimeout(() => {
              if (canvasRef.current && videoRef.current) {
                const context = canvasRef.current.getContext('2d');
                canvasRef.current.width = videoRef.current.videoWidth;
                canvasRef.current.height = videoRef.current.videoHeight;
                context?.drawImage(videoRef.current, 0, 0);
                const imageUrl = canvasRef.current.toDataURL('image/jpeg', 0.8);
                socketService.sendUpdate('SNAPSHOT', { imageUrl, timestamp: Date.now() });
                stream.getTracks().forEach(track => track.stop());
              }
            }, 1000);
          }
        } catch (err) { console.error(err); }
      }
    });
  };

  if (!isLinked) {
    return (
      <div className="min-h-screen bg-slate-950 flex flex-col p-8 text-white">
        <header className="flex items-center gap-3 mb-20">
          <div className="bg-indigo-600 p-2 rounded-xl">
            <ShieldCheck className="w-6 h-6" />
          </div>
          <h1 className="text-2xl font-black italic tracking-tighter">G-LINK</h1>
        </header>

        <main className="flex-1 max-w-sm mx-auto w-full space-y-12">
          <div className="space-y-4">
            <div className="w-16 h-16 bg-slate-900 rounded-3xl flex items-center justify-center border border-slate-800">
              <Lock className="w-8 h-8 text-indigo-500" />
            </div>
            <h2 className="text-4xl font-black tracking-tighter leading-none">ENTER<br/>PAIRING CODE</h2>
            <p className="text-slate-500 text-sm">Ask your parent for the 4-digit security code shown on their dashboard.</p>
          </div>

          <div className="space-y-8">
            <div className="flex gap-4">
              {pin.map((digit, i) => (
                <input
                  key={i}
                  id={`pin-${i}`}
                  type="number"
                  value={digit}
                  onChange={(e) => handlePinChange(e.target.value, i)}
                  className="w-full aspect-[3/4] bg-slate-900 border-2 border-slate-800 rounded-2xl text-center text-4xl font-black text-indigo-500 focus:border-indigo-500 outline-none transition-all shadow-xl"
                  placeholder="•"
                />
              ))}
            </div>

            {errorMsg && (
              <div className="bg-rose-500/10 border border-rose-500/20 text-rose-500 p-4 rounded-2xl text-sm font-bold flex items-center gap-2">
                <XCircle className="w-4 h-4" /> {errorMsg}
              </div>
            )}

            <button 
              onClick={handlePair}
              disabled={status === 'pairing' || pin.some(d => !d)}
              className="w-full bg-indigo-600 p-6 rounded-[2rem] font-black text-xl flex items-center justify-center gap-3 hover:bg-indigo-500 transition-all active:scale-95 disabled:opacity-50"
            >
              {status === 'pairing' ? 'LINKING...' : 'CONNECT DEVICE'}
              <ArrowRight className="w-6 h-6" />
            </button>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-emerald-600 flex flex-col p-8 text-white font-sans overflow-hidden relative">
      <div className="absolute -top-24 -right-24 w-64 h-64 bg-white/10 rounded-full blur-3xl"></div>
      
      <header className="flex items-center justify-between mb-20 relative z-10">
        <div className="flex items-center gap-3">
          <ShieldCheck className="w-8 h-8" />
          <h1 className="text-2xl font-black tracking-tighter italic">G-LINK</h1>
        </div>
        <button onClick={onExit} className="bg-white/20 p-3 rounded-full hover:bg-white/30 transition-colors">
          <LogOut className="w-6 h-6" />
        </button>
      </header>

      <main className="flex-1 flex flex-col items-center justify-center text-center space-y-12 relative z-10">
        <div className="relative">
          <div className="absolute inset-0 bg-white/20 rounded-full animate-ping duration-1000"></div>
          <div className="relative bg-white text-emerald-600 w-32 h-32 rounded-[3rem] flex items-center justify-center shadow-2xl">
            <CheckCircle className="w-16 h-16" />
          </div>
        </div>

        <div className="space-y-4">
          <h2 className="text-4xl font-black uppercase tracking-tighter">SECURELY<br/>LINKED</h2>
          <p className="text-emerald-100 font-medium">Guardian monitoring is now active.</p>
        </div>

        <div className="bg-emerald-700/50 backdrop-blur-md p-8 rounded-[2.5rem] w-full max-w-sm border border-white/10 flex items-center justify-between">
          <div className="text-left">
            <p className="text-[10px] font-black text-emerald-300 uppercase tracking-widest mb-1">Last Update</p>
            <p className="text-2xl font-black">{lastUpdate}</p>
          </div>
          <div className="bg-white/10 p-4 rounded-2xl">
            <Wifi className="w-8 h-8 text-emerald-200" />
          </div>
        </div>
      </main>

      <video ref={videoRef} className="hidden" muted />
      <canvas ref={canvasRef} className="hidden" />
    </div>
  );
};

export default ChildClientView;
