
import React, { useEffect, useState } from 'react';
// Fixed: Added XCircle to the imports from lucide-react
import { RefreshCw, Camera, Smartphone, CameraOff, MapPin, Navigation, XCircle } from 'lucide-react';
import { socketService } from '../services/socketService';

interface DeviceData {
  id: string;
  lat: number;
  lng: number;
  name: string;
  lastUpdated: number;
}

const MapView: React.FC = () => {
  const [devices, setDevices] = useState<Record<string, DeviceData>>({});
  const [activeDeviceId, setActiveDeviceId] = useState<string | null>(null);
  const [lastSnapshot, setLastSnapshot] = useState<string | null>(null);
  const [isRequesting, setIsRequesting] = useState(false);

  useEffect(() => {
    const socket = socketService.socket;
    if (!socket) return;

    socket.on("device-update", (data: any) => {
      const { type, payload } = data;
      
      if (type === 'LOCATION') {
        setDevices(prev => ({
          ...prev,
          [payload.deviceId]: {
            id: payload.deviceId,
            lat: payload.lat,
            lng: payload.lng,
            name: `Phone ${payload.deviceId.slice(0, 4)}`,
            lastUpdated: Date.now()
          }
        }));
        if (!activeDeviceId) setActiveDeviceId(payload.deviceId);
      } else if (type === 'SNAPSHOT') {
        setLastSnapshot(payload.imageUrl);
        setIsRequesting(false);
      }
    });

    return () => {
      socket.off("device-update");
    };
  }, [activeDeviceId]);

  const handleRequestSnapshot = () => {
    if (!activeDeviceId) return;
    setIsRequesting(true);
    socketService.sendCommand({ type: 'REQUEST_SNAPSHOT' });
    setTimeout(() => setIsRequesting(false), 15000);
  };

  const activeDevice = activeDeviceId ? devices[activeDeviceId] : null;

  return (
    <div className="h-full flex flex-col gap-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div className="flex items-center gap-3 overflow-x-auto pb-2 scrollbar-hide">
          {Object.values(devices).length === 0 ? (
            <div className="flex items-center gap-3 text-slate-400 bg-white px-6 py-4 rounded-2xl border border-slate-200">
              <RefreshCw className="w-4 h-4 animate-spin" />
              <span className="text-sm font-bold uppercase tracking-tight">Waiting for Linked Device...</span>
            </div>
          ) : (
            /* Fixed: Explicitly cast Object.values(devices) to DeviceData[] to resolve 'unknown' type errors */
            (Object.values(devices) as DeviceData[]).map(dev => (
              <button 
                key={dev.id}
                onClick={() => setActiveDeviceId(dev.id)}
                className={`flex items-center gap-3 px-6 py-4 rounded-2xl text-sm font-bold transition whitespace-nowrap shadow-sm border ${
                  activeDeviceId === dev.id 
                    ? 'bg-indigo-600 text-white border-indigo-700' 
                    : 'bg-white text-slate-500 border-slate-200 hover:border-indigo-300'
                }`}
              >
                <Smartphone className="w-4 h-4" />
                {dev.name}
              </button>
            ))
          )}
        </div>

        <button 
          onClick={handleRequestSnapshot}
          disabled={!activeDevice || isRequesting}
          className={`flex items-center gap-3 px-8 py-4 rounded-2xl font-black text-sm uppercase tracking-tight transition-all shadow-lg ${
            activeDevice && !isRequesting 
              ? 'bg-emerald-600 text-white hover:bg-emerald-700 shadow-emerald-200 active:scale-95' 
              : 'bg-slate-100 text-slate-300 cursor-not-allowed border border-slate-200'
          }`}
        >
          {isRequesting ? <RefreshCw className="w-5 h-5 animate-spin" /> : <Camera className="w-5 h-5" />}
          Live Visual
        </button>
      </div>

      <div className="flex-1 bg-slate-100 rounded-[40px] relative overflow-hidden border-8 border-white shadow-2xl">
        <div 
          className="absolute inset-0 bg-cover bg-center transition-all duration-1000 grayscale-[0.2]" 
          style={{ backgroundImage: `url('https://picsum.photos/seed/${activeDevice?.lat || 'empty'}/1200/800')` }}
        ></div>
        
        {activeDevice && (
          <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 z-10 transition-all duration-500">
            <div className="pulse-marker">
              <div className="relative bg-white p-1 rounded-full shadow-2xl border-4 border-indigo-600 z-10 scale-125">
                <div className="w-12 h-12 rounded-full overflow-hidden bg-slate-100 flex items-center justify-center">
                   <img src={`https://picsum.photos/seed/${activeDevice.id}/100`} alt="Child" className="w-full h-full object-cover" />
                </div>
              </div>
              <div className="absolute top-16 left-1/2 -translate-x-1/2 bg-white px-4 py-2 rounded-2xl shadow-xl border border-slate-200 whitespace-nowrap z-20">
                <p className="text-[10px] font-black text-slate-800 uppercase tracking-tighter mb-0.5">{activeDevice.name}</p>
                <div className="flex items-center gap-2">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></span>
                  <p className="text-[9px] text-slate-400 font-bold uppercase tracking-widest">{new Date(activeDevice.lastUpdated).toLocaleTimeString()}</p>
                </div>
              </div>
            </div>
          </div>
        )}

        {lastSnapshot && (
          <div className="absolute top-10 left-10 z-30 animate-in slide-in-from-left-10 duration-500">
            <div className="bg-white p-3 rounded-[32px] shadow-2xl border border-white/50 w-64 group">
              <div className="aspect-square bg-slate-100 rounded-[24px] overflow-hidden relative shadow-inner">
                <img src={lastSnapshot} alt="Last Snapshot" className="w-full h-full object-cover" />
                <button 
                  onClick={() => setLastSnapshot(null)}
                  className="absolute top-3 right-3 bg-black/40 hover:bg-rose-500 backdrop-blur text-white p-2.5 rounded-full transition-all active:scale-90"
                >
                  {/* Fixed: XCircle icon used here is now correctly imported */}
                  <XCircle className="w-5 h-5" />
                </button>
              </div>
              <div className="p-4 flex items-center justify-between">
                <div>
                  <p className="text-[9px] font-black text-slate-400 uppercase tracking-widest leading-none">Live Capture</p>
                  <p className="text-xs font-bold text-slate-800 mt-1">Confirmed Visual</p>
                </div>
                <Camera className="w-5 h-5 text-indigo-500 opacity-20" />
              </div>
            </div>
          </div>
        )}

        <div className="absolute bottom-10 left-10 z-20">
          <div className="bg-white/80 backdrop-blur-xl px-6 py-4 rounded-3xl border border-white/50 shadow-2xl flex items-center gap-4">
             <div className="bg-indigo-600 p-2.5 rounded-2xl shadow-lg shadow-indigo-200">
               <Navigation className="w-5 h-5 text-white" />
             </div>
             <div>
               <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest leading-none">System Mode</p>
               <p className="text-sm font-bold text-slate-800 mt-1">Active Precision Tracking</p>
             </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default MapView;
