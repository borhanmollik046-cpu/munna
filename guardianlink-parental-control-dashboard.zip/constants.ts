
import { CallLog, DeviceLocation, ScreenCapture, UsageStats } from './types';

export const MOCK_LOCATIONS: DeviceLocation[] = [
  { id: '1', latitude: 37.7749, longitude: -122.4194, timestamp: '2 minutes ago', accuracy: 15, batteryLevel: 82 },
];

export const MOCK_CALL_LOGS: CallLog[] = [
  { id: 'c1', contactName: 'Alex Smith', phoneNumber: '+1 (555) 010-2345', type: 'incoming', duration: '5m 12s', timestamp: '10:45 AM', riskScore: 'low' },
  { id: 'c2', contactName: 'Unknown', phoneNumber: '+1 (888) 999-0000', type: 'incoming', duration: '0s', timestamp: '09:15 AM', riskScore: 'medium' },
  { id: 'c3', contactName: 'Mom', phoneNumber: '+1 (555) 000-1111', type: 'outgoing', duration: '12m 45s', timestamp: 'Yesterday', riskScore: 'low' },
];

export const MOCK_SCREENSHOTS: ScreenCapture[] = [
  { 
    id: 's1', 
    imageUrl: 'https://picsum.photos/seed/app1/600/400', 
    timestamp: '15 mins ago', 
    appTitle: 'TikTok', 
    aiDescription: 'Viewing educational science content. Safe viewing.', 
    safetyRating: 95 
  },
  { 
    id: 's2', 
    imageUrl: 'https://picsum.photos/seed/app2/600/400', 
    timestamp: '45 mins ago', 
    appTitle: 'Messenger', 
    aiDescription: 'Group chat interaction. No bullying detected.', 
    safetyRating: 88 
  },
  { 
    id: 's3', 
    imageUrl: 'https://picsum.photos/seed/app3/600/400', 
    timestamp: '2 hours ago', 
    appTitle: 'Roblox', 
    aiDescription: 'Active gameplay. Potential for unknown contact interaction.', 
    safetyRating: 72 
  },
];

export const MOCK_USAGE: UsageStats[] = [
  { appName: 'TikTok', minutes: 120, category: 'Entertainment' },
  { appName: 'Roblox', minutes: 90, category: 'Games' },
  { appName: 'Duolingo', minutes: 45, category: 'Education' },
  { appName: 'WhatsApp', minutes: 30, category: 'Social' },
  { appName: 'Browser', minutes: 15, category: 'Other' },
];
