
import { GoogleGenAI, Type } from "@google/genai";
import { CallLog, AISafetyInsight } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function analyzeCallLogs(logs: CallLog[]): Promise<AISafetyInsight[]> {
  const prompt = `Analyze these call logs for potential safety risks for a child. Look for unknown numbers, late night calls, or suspicious patterns. Return a JSON list of insights.
  Logs: ${JSON.stringify(logs)}`;

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
      config: {
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              type: { type: Type.STRING, description: 'warning, info, or positive' },
              message: { type: Type.STRING },
              recommendation: { type: Type.STRING }
            },
            required: ['type', 'message', 'recommendation']
          }
        }
      }
    });

    const text = response.text || '[]';
    return JSON.parse(text);
  } catch (error) {
    console.error("AI analysis failed:", error);
    return [
      { type: 'info', message: 'AI Analysis currently unavailable.', recommendation: 'Please check logs manually.' }
    ];
  }
}

export async function getGeneralSafetyReport(): Promise<string> {
  const prompt = "Generate a concise daily digital safety report for a parent based on typical modern teen app usage (TikTok, Roblox, Discord). Provide 3 key focus areas.";
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: prompt,
    });
    return response.text || "Report generation failed.";
  } catch {
    return "Unable to generate summary at this time.";
  }
}
