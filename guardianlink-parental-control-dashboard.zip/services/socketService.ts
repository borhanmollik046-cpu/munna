
import { io, Socket } from "socket.io-client";

class SocketService {
  public socket: Socket | null = null;
  private currentPairCode: string | null = null;

  // For Netlify deployment, you can set the environment variable VITE_SOCKET_URL
  // If not provided, it defaults to the current origin (assuming local development)
  private getBackendUrl() {
    return (import.meta as any).env?.VITE_SOCKET_URL || window.location.origin;
  }

  connect() {
    if (this.socket?.connected) return this.socket;
    
    const url = this.getBackendUrl();
    console.log("Connecting to GuardianLink Bridge at:", url);
    
    this.socket = io(url, {
      transports: ['websocket', 'polling'], // Better compatibility for different hosts
      reconnection: true,
      reconnectionAttempts: 10
    });
    
    this.socket.on("connect", () => {
      console.log("Socket Connected:", this.socket?.id);
    });

    this.socket.on("connect_error", (err) => {
      console.error("Socket Connection Error. Check if your backend server is running:", err);
    });

    return this.socket;
  }

  requestPairingCode(callback: (code: string) => void) {
    this.socket?.emit('request-pairing-code');
    this.socket?.once('pairing-code-generated', (code: string) => {
      this.currentPairCode = code;
      callback(code);
    });
  }

  linkWithCode(code: string, onResult: (success: boolean, message?: string) => void) {
    this.socket?.emit('link-with-code', code);
    this.socket?.once('pairing-success', () => {
      this.currentPairCode = code;
      onResult(true);
    });
    this.socket?.once('pairing-error', (err: string) => onResult(false, err));
  }

  sendUpdate(type: string, payload: any) {
    if (!this.currentPairCode) return;
    this.socket?.emit('child-update', { code: this.currentPairCode, type, payload });
  }

  sendCommand(command: any) {
    if (!this.currentPairCode) return;
    this.socket?.emit('parent-command', { code: this.currentPairCode, command });
  }

  disconnect() {
    this.socket?.disconnect();
    this.socket = null;
    this.currentPairCode = null;
  }

  getPairCode() { return this.currentPairCode; }
}

export const socketService = new SocketService();
