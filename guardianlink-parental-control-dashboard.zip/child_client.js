
/**
 * ANDROID CLIENT SCRIPT (Simulated)
 * Run this on the "child's device" to connect to the server.
 */
const { io } = require("socket.io-client");

const SERVER_URL = "http://localhost:3000";
const socket = io(SERVER_URL);

console.log("Connecting to GuardianLink Bridge...");

socket.on("connect", () => {
  console.log("Child Device Online. Joined tracking pool.");
  socket.emit("join-room", "children");

  // Simulate periodic GPS updates
  setInterval(() => {
    const lat = 37.7749 + (Math.random() - 0.5) * 0.01;
    const lng = -122.4194 + (Math.random() - 0.5) * 0.01;
    
    socket.emit("child-update", {
      type: "LOCATION",
      payload: { lat, lng, deviceId: "child-phone-001" }
    });
  }, 5000);
});

// Listen for commands from the Parent Dashboard
socket.on("child-command", (command) => {
  console.log("RECEIVED COMMAND:", command.type);

  if (command.type === "REQUEST_SNAPSHOT") {
    console.log("Triggering camera capture...");
    
    // Simulate capture delay and image generation
    setTimeout(() => {
      const mockSnapshotUrl = `https://picsum.photos/seed/${Math.random()}/800/600`;
      socket.emit("child-update", {
        type: "SNAPSHOT",
        payload: { imageUrl: mockSnapshotUrl, timestamp: Date.now() }
      });
      console.log("Snapshot sent back to parent.");
    }, 2000);
  }
});

socket.on("disconnect", () => {
  console.log("Disconnected from server.");
});
