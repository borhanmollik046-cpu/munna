
export interface DeviceLocation {
  id: string;
  latitude: number;
  longitude: number;
  timestamp: string;
  accuracy: number;
  batteryLevel: number;
}

export interface CallLog {
  id: string;
  contactName: string;
  phoneNumber: string;
  type: 'incoming' | 'outgoing' | 'missed';
  duration: string;
  timestamp: string;
  riskScore: 'low' | 'medium' | 'high';
}

export interface ScreenCapture {
  id: string;
  imageUrl: string;
  timestamp: string;
  appTitle: string;
  aiDescription: string;
  safetyRating: number;
}

export interface UsageStats {
  appName: string;
  minutes: number;
  category: 'Social' | 'Games' | 'Education' | 'Entertainment' | 'Other';
}

export interface AISafetyInsight {
  type: 'warning' | 'info' | 'positive';
  message: string;
  recommendation: string;
}
